export interface PortfolioItem {
  id: number;
  title: string;
  category: string;
  description?: string;
  githubUrl?: string;
  liveUrl?: string;
  dataUrl: string;
  date: string;
  sizeKb: string;
  isPermanent?: boolean;
}

// Specific IDs and Titles of any legacy placeholder sample projects to ignore
export const PLACEHOLDER_PROJECT_IDS = new Set<number>([
  1710000001,
  1710000002,
  1710000003,
  1710000004,
  1710000005,
  1710000006,
]);

export const PLACEHOLDER_PROJECT_TITLES = new Set<string>([
  'Kyoto Artisan Cafe & Roastery',
  'Siam Bistro Modern Dining Experience',
  'Marina Horizon Residences & Architecture',
  'Apex Prime Real Estate',
]);

// 12 Real Production Deliverables with verified live deployments and GitHub repositories
export const HARDCODED_PROJECTS: PortfolioItem[] = [
  {
    id: 101,
    title: 'FDFN Broadband & ISP Management Platform',
    category: 'Custom Web',
    description: 'Enterprise internet service provider infrastructure with live package subscriptions, coverage mapping, and network operations dashboard.',
    githubUrl: 'https://github.com/nayemurrr/fdfn.claws',
    liveUrl: 'https://v2-internet-provider.web.app/',
    dataUrl: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=800&q=80',
    date: '2026-03-15',
    sizeKb: '52.4',
    isPermanent: true,
  },
  {
    id: 102,
    title: 'E-Shop MERN E-Commerce Platform',
    category: 'E-commerce',
    description: 'Full-stack MERN online commerce application featuring dynamic product catalogs, persistent shopping cart, and Stripe payment integration.',
    githubUrl: 'https://github.com/nayemurrr/e_shop',
    liveUrl: 'https://e-shop-01.web.app/',
    dataUrl: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
    date: '2026-03-12',
    sizeKb: '48.7',
    isPermanent: true,
  },
  {
    id: 103,
    title: 'Google Search Engine Experience',
    category: 'Custom Web',
    description: 'Next.js and Tailwind CSS powered search engine application engineered for lightning response times and clean search indexing.',
    githubUrl: 'https://github.com/nayemurrr/google_claws',
    liveUrl: 'https://google-clone-nayem1816.vercel.app/',
    dataUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=800&q=80',
    date: '2026-03-10',
    sizeKb: '40.5',
    isPermanent: true,
  },
  {
    id: 104,
    title: 'TeleDoctor Healthcare & Telemedicine Portal',
    category: 'Custom Web',
    description: 'TeleDoctor healthcare platform enabling seamless patient-doctor communication, appointment booking, Chart.js vitals, and Stripe billing.',
    githubUrl: 'https://github.com/nayemurrr/tele_doctor_claws',
    liveUrl: 'https://tele-doctor-uu.web.app/',
    dataUrl: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=800&q=80',
    date: '2026-03-08',
    sizeKb: '56.4',
    isPermanent: true,
  },
  {
    id: 105,
    title: 'React & Redux Shopping Experience',
    category: 'E-commerce',
    description: 'High-performance React & Redux state-driven virtual storefront featuring real-time inventory calculation and checkout.',
    githubUrl: 'https://github.com/nayemurrr/react_shopping_cart',
    liveUrl: 'https://react-shopping-cart-nym.web.app/',
    dataUrl: 'https://images.unsplash.com/photo-1472851294608-062f824d29cc?auto=format&fit=crop&w=800&q=80',
    date: '2026-03-05',
    sizeKb: '44.1',
    isPermanent: true,
  },
  {
    id: 106,
    title: 'Apex Banking & Financial Transaction System',
    category: 'Custom Web',
    description: 'Secure digital banking simulator with ledger transaction records, account balance auditing, and instant fund transfers.',
    githubUrl: 'https://github.com/nayemurrr/banking_system',
    liveUrl: 'https://banking-system-psi.vercel.app/',
    dataUrl: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?auto=format&fit=crop&w=800&q=80',
    date: '2026-02-28',
    sizeKb: '52.1',
    isPermanent: true,
  },
  {
    id: 107,
    title: 'Anchorblock Task Management Platform',
    category: 'Custom Web',
    description: 'Production-grade project scheduling and task organization dashboard with responsive state tracking and workflow categorization.',
    githubUrl: 'https://github.com/nayemurrr/anchorblock_task',
    liveUrl: 'https://anchorblock-task-peach.vercel.app/',
    dataUrl: 'https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?auto=format&fit=crop&w=800&q=80',
    date: '2026-02-24',
    sizeKb: '43.8',
    isPermanent: true,
  },
  {
    id: 108,
    title: 'Baran Fitness Club & Gym Membership Portal',
    category: 'Custom Web',
    description: 'Modern fitness center web application featuring membership tiers, workout routine tracking, and personal trainer booking.',
    githubUrl: 'https://github.com/nayemurrr/gym_baran',
    liveUrl: 'https://gym-baran-gamma.vercel.app/',
    dataUrl: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=800&q=80',
    date: '2026-02-20',
    sizeKb: '64.2',
    isPermanent: true,
  },
  {
    id: 109,
    title: 'PrivaLink Secure Communication Utility',
    category: 'Custom Web',
    description: 'Encrypted link and privacy-focused communication tool designed for secure client messaging and data exchange.',
    githubUrl: 'https://github.com/nayemurrr/priva_link_claws',
    liveUrl: 'https://priva-link-client.vercel.app/',
    dataUrl: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=800&q=80',
    date: '2026-02-15',
    sizeKb: '39.0',
    isPermanent: true,
  },
  {
    id: 110,
    title: 'Nova Boutique & Apparel E-Commerce Store',
    category: 'E-commerce',
    description: 'Responsive apparel and goods digital storefront built with optimized product showcases and intuitive cart management.',
    githubUrl: 'https://github.com/nayemurrr/e_commerce',
    liveUrl: 'https://e-commerce-nym.netlify.app/',
    dataUrl: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=800&q=80',
    date: '2026-02-10',
    sizeKb: '58.9',
    isPermanent: true,
  },
  {
    id: 111,
    title: 'Temperature Hot Global Weather Forecast App',
    category: 'Custom Web',
    description: 'Live city temperature search and meteorological data visualizer fetching real-time atmospheric data worldwide.',
    githubUrl: 'https://github.com/nayemurrr/temperature_hot',
    liveUrl: 'https://nayem1816.github.io/temperature-hot/',
    dataUrl: 'https://images.unsplash.com/photo-1592210454359-9043f067919b?auto=format&fit=crop&w=800&q=80',
    date: '2026-02-05',
    sizeKb: '36.7',
    isPermanent: true,
  },
  {
    id: 112,
    title: 'TaskMaster Cloud Todo & Productivity App',
    category: 'Custom Web',
    description: 'Cloud-synchronized task planner and productivity suite featuring instant state updates and tag filtering.',
    githubUrl: 'https://github.com/nayemurrr/todo_apps',
    liveUrl: 'https://my-todo-nym.web.app/',
    dataUrl: 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&w=800&q=80',
    date: '2026-01-28',
    sizeKb: '33.9',
    isPermanent: true,
  },
];

// Initial default items guaranteed to render statically on any external visitor/reviewer load
export const INITIAL_PORTFOLIO_ITEMS: PortfolioItem[] = HARDCODED_PROJECTS;
